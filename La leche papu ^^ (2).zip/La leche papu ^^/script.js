const musica1 = document.getElementById("musica1");

const musica2 = document.getElementById("musica2");

document.addEventListener("click", () => {

    musica1.play();

}, { once:true });

musica1.addEventListener("ended", () => {

    musica2.play();

});